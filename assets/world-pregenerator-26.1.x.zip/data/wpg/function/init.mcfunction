scoreboard objectives add wpg dummy {"text":"WPG","color":"aqua"}
scoreboard players set initialized wpg 1
scoreboard players set start wpg 0
scoreboard players set ticks wpg 0
scoreboard players set seconds wpg 0
scoreboard players set delay wpg 10
scoreboard players set step wpg 0
scoreboard players set next_turn wpg 1
scoreboard players set counter_seconds wpg 0
scoreboard players set counter_minutes wpg 0
scoreboard players set counter_hours wpg 0
scoreboard players set counter_days wpg 0
scoreboard players set counter_steps wpg 0
tellraw @a [{"color":"gray","text":"> > > "},{"bold":true,"color":"aqua","text":"World Pregenerator"},{"color":"gray","text":" < < <\n"},{"click_event":{"action":"run_command","command":"/function wpg:start"},"color":"dark_aqua","hover_event":{"action":"show_text","value":[{"text":"/function ","color":"gray"},{"text":"wpg:start","color":"aqua"}]},"text":"Click here"},{"color":"white","text":" to start the world pregeneration process\n"},{"click_event":{"action":"suggest_command","command":"/scoreboard players set delay wpg "},"color":"dark_aqua","hover_event":{"action":"show_text","value":[{"text":"/scoreboard players set ","color":"gray"},{"text":"delay ","color":"aqua"},{"text":"wpg ","color":"yellow"},{"text":"<seconds>","color":"green"}]},"text":"Click here"},{"color":"white","text":" to set the delay between teleports (in seconds)\n"},{"click_event":{"action":"run_command","command":"/tp @s 0 ~ 0 0 0"},"color":"dark_aqua","hover_event":{"action":"show_text","value":[{"text":"/tp ","color":"gray"},{"text":"@s ","color":"aqua"},{"text":"0 ~ 0 ","color":"yellow"},{"text":"0 0","color":"green"}]},"text":"Click here"},{"color":"white","text":" to teleport to (0, 0)\n"},{"click_event":{"action":"run_command","command":"/function wpg:stop"},"color":"dark_aqua","hover_event":{"action":"show_text","value":[{"text":"/function ","color":"gray"},{"text":"wpg:stop","color":"aqua"}]},"text":"Click here"},{"color":"white","text":" to stop the pregeneration process\n"},{"color":"gray","text":"> > > "},{"click_event":{"action":"open_url","url":"https://meeples10.github.io/"},"color":"aqua","hover_event":{"action":"show_text","value":[{"text":"https://meeples10.github.io/","color":"aqua"}]},"text":"meeples10.github.io"},{"color":"gray","text":" < < <"}]
