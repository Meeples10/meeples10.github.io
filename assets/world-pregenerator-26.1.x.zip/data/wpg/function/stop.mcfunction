scoreboard players set start wpg 0
