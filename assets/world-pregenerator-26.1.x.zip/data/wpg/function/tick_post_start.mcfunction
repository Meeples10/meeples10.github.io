scoreboard players add ticks wpg 1
execute if score ticks wpg matches 20.. run scoreboard players add seconds wpg 1
execute if score ticks wpg matches 20.. run scoreboard players add counter_seconds wpg 1
execute if score ticks wpg matches 20.. run scoreboard players set ticks wpg 0
execute if score seconds wpg >= delay wpg run function wpg:step
execute if score seconds wpg >= delay wpg run scoreboard players set seconds wpg 0
execute if score counter_seconds wpg matches 60 run scoreboard players add counter_minutes wpg 1
execute if score counter_seconds wpg matches 60 run scoreboard players set counter_seconds wpg 1
execute if score counter_minutes wpg matches 60 run scoreboard players add counter_hours wpg 1
execute if score counter_minutes wpg matches 60 run scoreboard players set counter_minutes wpg 0
execute if score counter_hours wpg matches 24 run scoreboard players add counter_days wpg 1
execute if score counter_hours wpg matches 24 run scoreboard players set counter_hours wpg 0
title @a actionbar [{"color":"aqua","text":"WPG "},{"color":"gray","text":"["},{"color":"dark_aqua","score":{"name":"counter_days","objective":"wpg"}},{"color":"gray","text":"d "},{"color":"dark_aqua","score":{"name":"counter_hours","objective":"wpg"}},{"color":"gray","text":"h "},{"color":"dark_aqua","score":{"name":"counter_minutes","objective":"wpg"}},{"color":"gray","text":"m "},{"color":"dark_aqua","score":{"name":"counter_seconds","objective":"wpg"}},{"color":"gray","text":"s] (step "},{"color":"yellow","score":{"name":"counter_steps","objective":"wpg"}},{"color":"gray","text":", "},{"color":"red","score":{"name":"step","objective":"wpg"}},{"color":"gray","text":"/"},{"color":"red","score":{"name":"next_turn","objective":"wpg"}},{"color":"gray","text":")"}]
