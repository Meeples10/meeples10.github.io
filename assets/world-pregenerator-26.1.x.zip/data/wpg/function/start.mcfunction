scoreboard players set start wpg 1
