scoreboard players set start wpg 1
gamemode spectator @a
