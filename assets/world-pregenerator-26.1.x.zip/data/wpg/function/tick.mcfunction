execute store result storage wpg:storage Initialized byte 1 run scoreboard players get initialized wpg
execute if data storage wpg:storage {Initialized:0b} run function wpg:init
execute if score start wpg matches 1 run function wpg:tick_post_start
