scoreboard players add step wpg 1
scoreboard players add counter_steps wpg 1
execute as @a at @s run tp @s ^ ^ ^256 ~ 0
execute if score step wpg = next_turn wpg run function wpg:turn
