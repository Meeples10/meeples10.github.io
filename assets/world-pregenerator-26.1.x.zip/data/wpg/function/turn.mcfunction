execute as @a at @s run tp @s ~ ~ ~ ~90 ~
scoreboard players set step wpg 0
scoreboard players add next_turn wpg 1
